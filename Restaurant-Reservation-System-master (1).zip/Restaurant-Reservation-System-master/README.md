Restaurant Reservation System 

This project is used by both clients and employees, clients can create a new account or make an order while the the other employees like manager,cooker and waiter receive the order and have access to it. 

Getting Started 

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system. 

Prerequisites 

JavaFX package 

Running the tests 

Client: 

First you run the program, the program will require the username and password, write one from the exsiting data which was set in (pom.xml) file, if you enter as a Client, you will be navigated to the menu dashboard, First, click at table tab to choose from the avaliable tables provided by the restaurant then after clicking confirm, you will be navigated to the menu , finally you can choose your order and then click “confirm order” button to confirm. 

If you want to add another order to the table ,please choose your new meal then press confirm order, do not click on (Add Order), where (Add Order) will require you to choose a new table. 

You have two choices, either you add a new meal to the same table or reserve a new table. 

Manager: Manager has access to the table reserved, total amount of money before and after taxes and view the list of orders beside their client names. 

Waiter: Waiter has access to the tables reserved and their Client names 

Cooker: Cooker has access to the orders beside the table number where the order goes 

 

Break down into end to end tests 

These data will be saved automatically after submitting the order, where the employees can see the data upon their provided access. 

Features 

We made an option where a new client can register and start using the system. 

And coding style tests 

Explain what these tests test and why 

Give an example 

Built With 

JavaFX 

Example for an existing username and password. 

You can find the rest of the usernames and passwords in a file named “pom.xml” 

Client: 

Username:john 

Password:john_doe 

Manager: 

Username:adam 

Password:adam_manager 

 

Contribution 

Rowan Hussein  

Amr Mahdy  
